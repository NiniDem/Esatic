// Fichier: mainwindow.h
#ifndef MAINWINDOW_H
#define MAINWINDOW_H
#include <QMainWindow>
#include <QPushButton>
#include <QVBoxLayout>
#include "fenetreenseignant.h"
#include "fenetredepartement.h"
#include "fenetrematiere.h"
#include "fenetrecollege.h"
#include "fenetrenote.h"
#include "fenetreetudiant.h"
#include "fenetredocumentation.h"

class MainWindow : public QMainWindow {
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);

private slots:
    void ouvrirGestionEnseignant();
    void ouvrirGestionDepartement();
    void ouvrirGestionMatiere();
    void ouvrirGestionCollege();
    void ouvrirGestionNote();
    void ouvrirGestionEtudiant();
    void ouvrirGestionDocumentation();

private:
    QPushButton *btnEnseignants;
    QPushButton *btnDepartements;
    QPushButton *btnMatieres;
    QPushButton *btnColleges;
    QPushButton *btnNotes;
    QPushButton *btnEtudiant;
     QPushButton *btnDocumentation;

};

#endif
