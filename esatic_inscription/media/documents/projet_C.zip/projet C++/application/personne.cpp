#include "personne.h"
#include <iostream>

// Implémentation complète du constructeur
personne::personne(std::string n, std::string p, std::string t, std::string m)
    :nom(n), prenom(p), tel(t), mail(m) {}

// Si besoin d'une méthode par défaut (optionnel)
void personne::afficherFiche() const {
    std::cout << "Nom: " << nom << "\nPrénom: " << prenom
              << "\nTéléphone: " << tel << "\nMail: " << mail << std::endl;
}

std::string personne::getNom() const {
    return nom;
}
