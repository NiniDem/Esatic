// Fichier: fenetrematiere.h
#ifndef FENETREMATIERE_H
#define FENETREMATIERE_H
#include <QDialog>
#include <QVBoxLayout>
#include <QPushButton>
#include <string>
#include "fenetreenseignant.h"

class fenetrematiere : public QDialog {
    Q_OBJECT
public:
    fenetrematiere(QWidget *parent = nullptr);
     fenetrematiere(std::string n, std::string s, int c);

private slots:
    void creerMatiere();
    void assignerEnseignant(fenetreenseignant* ens);
    void lierSalle();
    void afficherMatiereSansNotes();

private:
    QPushButton *btnCreer;
    QPushButton *btnAssigner;
    QPushButton *btnLierSalle;
    QPushButton *btnAfficherSansNotes;
    std::string nom;
    std::string salle;
    int capacite;
    std::vector<fenetreenseignant*> enseignants;

};

#endif
