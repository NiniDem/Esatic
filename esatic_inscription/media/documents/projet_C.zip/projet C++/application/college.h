
// Fichier: college.h
#ifndef COLLEGE_H
#define COLLEGE_H
#include <string>
#include <vector>
#include "departement.h"

class college {
private:
    std::string nom;
    std::string siteWeb;
    std::vector<departement> departements;

public:
    college(std::string n, std::string site);
    void ajouterDepartement(departement d);
    void afficherInfos() const;
};

#endif
