#include "fenetredepartement.h"
#include "connexion_mysql.h"
#include <QMessageBox>
#include <QInputDialog>


// Constructeur
fenetredepartement::fenetredepartement(QWidget *parent, std::string n)
    : QDialog(parent), nom(n), responsable(nullptr) {
    QVBoxLayout *layout = new QVBoxLayout(this);
    btnCreer = new QPushButton("Créer Département", this);
    btnAssigner = new QPushButton("Assigner Enseignant", this);
    btnResponsable = new QPushButton("Changer Responsable", this);

    layout->addWidget(btnCreer);
    layout->addWidget(btnAssigner);
    layout->addWidget(btnResponsable);

    connect(btnCreer, &QPushButton::clicked, this, &fenetredepartement::creerDepartement);
    connect(btnAssigner, &QPushButton::clicked, this, &fenetredepartement::assignerEnseignant);
    connect(btnResponsable, &QPushButton::clicked, this, &fenetredepartement::changerResponsable);
}

// Getter pour le nom du département
std::string fenetredepartement::getNom() const {
    return nom;
}

// Setter pour le nom du département
void fenetredepartement::setNom(const std::string& nouveauNom) {
    nom = nouveauNom;
}


// Créer un département
void fenetredepartement::creerDepartement() {
    if (!vraiconnexionBD()) return;

    QString nomDept = QInputDialog::getText(this, "Créer Département",
                                            "Nom du Département :");

    if (nomDept.isEmpty()) return;

    QSqlQuery query;
    query.prepare("INSERT INTO departements (nom) VALUES (:nom)");
    query.bindValue(":nom", nomDept);

    if (query.exec()) {
        QMessageBox::information(this, "Succès", "Département créé avec succès !");
    } else {
        QMessageBox::critical(this, "Erreur", "Erreur lors de la création : " + query.lastError().text());
    }
}

// Assigner un enseignant comme responsable du département
void fenetredepartement::assignerEnseignant() {
    if (!vraiconnexionBD()) return;

    QString nomEnseignant = QInputDialog::getText(this, "Assigner Responsable",
                                                  "Nom de l'enseignant :");

    if (nomEnseignant.isEmpty()) return;

    QSqlQuery query;
    query.prepare("UPDATE departements SET responsable = :enseignant WHERE nom = :nom");
    query.bindValue(":enseignant", nomEnseignant);
    query.bindValue(":nom", QString::fromStdString(nom));

    if (query.exec()) {
        QMessageBox::information(this, "Succès", "Responsable assigné avec succès !");
    } else {
        QMessageBox::critical(this, "Erreur", "Erreur lors de l'assignation : " + query.lastError().text());
    }
}

// Changer le responsable du département
void fenetredepartement::changerResponsable() {
    if (!vraiconnexionBD()) return;

    QString nomDepartement = QInputDialog::getText(this, "Changer Responsable",
                                                   "Nom du département :");
    QString nomEnseignant = QInputDialog::getText(this, "Nom Responsable",
                                                  "Nom du nouvel enseignant :");

    QSqlQuery query;
    query.prepare("UPDATE departements SET responsable = :responsable WHERE nom = :nom");
    query.bindValue(":responsable", nomEnseignant);
    query.bindValue(":nom", nomDepartement);

    if (query.exec()) {
        QMessageBox::information(this, "Succès", "Responsable changé avec succès !");
    } else {
        QMessageBox::critical(this, "Erreur", "Erreur lors de la modification : " + query.lastError().text());
    }
}
