#ifndef FENETREENSEIGNANT_H
#define FENETREENSEIGNANT_H

#include <QDialog>
#include <QVBoxLayout>
#include <QPushButton>
#include <string>
#include <QSqlDatabase>
#include "personne.h"

class fenetreenseignant : public QDialog, public personne {
    Q_OBJECT
public:
    fenetreenseignant(QWidget *parent = nullptr);
    fenetreenseignant(std::string n, std::string p, std::string t, std::string m, std::string date, int i, std::string mat, QWidget *parent = nullptr);

    void afficherFiche() const override;
    std::string getNom() const override;

private slots:
    void ajouter();
    void modifier();
    void supprimer();
    void imprimerFiche();  // SLOT déclaré ici (OK)

private:
    QPushButton *btnAjouter;
    QPushButton *btnModifier;
    QPushButton *btnSupprimer;
    QPushButton *btnImprimerFiche;

    std::string datePriseFonction;
    int indice;
    std::string matiere;
};

#endif
