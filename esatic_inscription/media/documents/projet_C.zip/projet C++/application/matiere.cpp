// Fichier: matiere.cpp
#include "matiere.h"

matiere::matiere(std::string n, std::string s, int c) : nom(n), salle(s), capacite(c) {}

void matiere::ajouterEnseignant(enseignant* ens) {
    enseignants.push_back(ens);
}

void matiere::afficherInfos() const {
    std::cout << "Matiere: " << nom << "\n";
    std::cout << "Salle: " << salle << " | Capacite: " << capacite << "\n";
}
