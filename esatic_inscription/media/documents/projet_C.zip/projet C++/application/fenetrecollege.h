#ifndef FENETRECOLLEGE_H
#define FENETRECOLLEGE_H

#include <QDialog>
#include <QVBoxLayout>
#include <QPushButton>
#include "fenetredepartement.h"
#include <vector>
#include <QLineEdit>
#include <QLabel>
#include <QTableWidget>
#include "connexion_mysql.h"

class fenetrecollege : public QDialog {
    Q_OBJECT
public:
    explicit fenetrecollege(QWidget *parent = nullptr);

private slots:
    void handleAjouter();
    void handleModifier();
    void handleSupprimer();

private:
    std::vector<fenetredepartement*> departements;  // Liste des départements
    void ajouter(fenetredepartement& d);
    void modifier(fenetredepartement& d);
    void supprimer(fenetredepartement& d);
    void affichercollege();

    QLineEdit *inputNom;
    QLineEdit *inputAdresse;
    QLineEdit *inputSiteWeb;
    QLineEdit *inputDirecteur;
    QLineEdit *inputTel;
    QTableWidget *tableColleges;

    QPushButton *btnAjouter;
    QPushButton *btnModifier;
    QPushButton *btnSupprimer;
    QPushButton *btnAfficher;
};

#endif // FENETRECOLLEGE_H
