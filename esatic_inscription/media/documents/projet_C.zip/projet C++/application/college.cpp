// Fichier: college.cpp
#include "college.h"
#include <string>
#include <iostream>

college::college(std::string n, std::string site) : nom(n), siteWeb(site) {}

void college::ajouterDepartement(departement d) {
    departements.push_back(d);
}

void college::afficherInfos() const {
    std::cout << "College: " << nom << "\n";
    std::cout << "Site Web: " << siteWeb << "\n";
}
