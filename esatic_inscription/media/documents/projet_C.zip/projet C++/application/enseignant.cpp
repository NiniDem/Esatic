// Fichier: enseignant.cpp
#include "enseignant.h"

enseignant::enseignant(std::string n, std::string p, std::string t, std::string m, std::string date, int i, std::string mat)
    : personne(n, p, t, m), datePriseFonction(date), indice(i), matiere(mat) {}

void enseignant::assignerMatiere(std::string mat) {
    matiere = mat;
}

void enseignant::afficherFiche() const {
    std::cout << "Enseignant: " << nom << " " << prenom << "\n";
    std::cout << "Matiere: " << matiere << "\n";
    std::cout << "Mail: " << mail << "\n";
}
