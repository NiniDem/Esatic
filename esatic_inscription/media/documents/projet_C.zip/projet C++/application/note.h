// Fichier: note.h
#ifndef NOTE_H
#define NOTE_H
#include <string>

class note {
private:
    std::string matiere;
    float valeur;

public:
    note(std::string m, float v);
    float getValeur() const;
    std::string getMatiere() const;
};

#endif
