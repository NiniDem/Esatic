#include "fenetrecollege.h"
#include "connexion_mysql.h"
#include <QSqlQuery>
#include <QSqlError>
#include <QMessageBox>
#include <QHeaderView>


// Constructeur
fenetrecollege::fenetrecollege(QWidget *parent) : QDialog(parent) {
    QVBoxLayout *layout = new QVBoxLayout(this);

    QLabel *labelNom = new QLabel("Nom du Collège:");
    inputNom = new QLineEdit(this);

    QLabel *labelAdresse = new QLabel("Adresse:");
    inputAdresse = new QLineEdit(this);

    QLabel *labelSite = new QLabel("Site Web:");
    inputSiteWeb = new QLineEdit(this);

    QLabel *labelDirecteur = new QLabel("Directeur:");
    inputDirecteur = new QLineEdit(this);

    QLabel *labelTel = new QLabel("Téléphone:");
    inputTel = new QLineEdit(this);

    btnAjouter = new QPushButton("Ajouter Collège", this);
    btnModifier = new QPushButton("Modifier Collège", this);
    btnSupprimer = new QPushButton("Supprimer Collège", this);
    btnAfficher = new QPushButton("Afficher Collèges", this);

    tableColleges = new QTableWidget(this);
    tableColleges->setColumnCount(5);
    tableColleges->setHorizontalHeaderLabels(QStringList() << "Nom" << "Adresse" << "Site Web" << "Directeur" << "Téléphone");
    tableColleges->horizontalHeader()->setSectionResizeMode(QHeaderView::Stretch);

    layout->addWidget(labelNom);
    layout->addWidget(inputNom);
    layout->addWidget(labelAdresse);
    layout->addWidget(inputAdresse);
    layout->addWidget(labelSite);
    layout->addWidget(inputSiteWeb);
    layout->addWidget(labelDirecteur);
    layout->addWidget(inputDirecteur);
    layout->addWidget(labelTel);
    layout->addWidget(inputTel);
    layout->addWidget(btnAjouter);
    layout->addWidget(btnModifier);
    layout->addWidget(btnSupprimer);
    layout->addWidget(btnAfficher);
    layout->addWidget(tableColleges);

    connect(btnAjouter, &QPushButton::clicked, this, &fenetrecollege::handleAjouter);
    connect(btnModifier, &QPushButton::clicked, this, &fenetrecollege::handleModifier);
    connect(btnSupprimer, &QPushButton::clicked, this, &fenetrecollege::handleSupprimer);
    connect(btnAfficher, &QPushButton::clicked, this, &fenetrecollege::affichercollege);

    affichercollege();  // Charger les collèges au démarrage
}

// --- Méthodes pour gérer les boutons ---

void fenetrecollege::handleAjouter() {
    fenetredepartement *d = new fenetredepartement(nullptr, inputNom->text().toStdString());
    ajouter(*d);
}

void fenetrecollege::handleModifier() {
    fenetredepartement *d = new fenetredepartement(nullptr, inputNom->text().toStdString());
    modifier(*d);
}

void fenetrecollege::handleSupprimer() {
    fenetredepartement *d = new fenetredepartement(nullptr, inputNom->text().toStdString());
    supprimer(*d);
}

// Ajouter un département
void fenetrecollege::ajouter(fenetredepartement& d) {
    ajouterCollege(inputNom->text(), inputAdresse->text(), inputSiteWeb->text(), inputDirecteur->text(), inputTel->text());
    affichercollege();
}

// Modifier un département
void fenetrecollege::modifier(fenetredepartement& d) {
    modifierCollege(inputNom->text(), inputAdresse->text(), inputSiteWeb->text(), inputDirecteur->text(), inputTel->text());
    affichercollege();
}

// Supprimer un département
void fenetrecollege::supprimer(fenetredepartement& d) {
    supprimerCollege(inputNom->text());
    affichercollege();
}

// Afficher les collèges
void fenetrecollege::affichercollege() {
    tableColleges->setRowCount(0);

    if (!vraiconnexionBD()) return;

    QSqlQuery query("SELECT nom, adresse, site_web, directeur, telephone FROM college");

    int row = 0;
    while (query.next()) {
        tableColleges->insertRow(row);
        for (int col = 0; col < 5; ++col) {
            tableColleges->setItem(row, col, new QTableWidgetItem(query.value(col).toString()));
        }
        row++;
    }
}
