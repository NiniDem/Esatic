
#include "fenetrematiere.h"
#include "salle.h"
#include <QMessageBox>

// Constructeur par défaut
fenetrematiere::fenetrematiere(QWidget *parent) : QDialog(parent) {
    QVBoxLayout *layout = new QVBoxLayout(this);
    btnCreer = new QPushButton("Créer Matière", this);
    btnAssigner = new QPushButton("Assigner Enseignant", this);
    btnLierSalle = new QPushButton("Lier Salle", this);
    btnAfficherSansNotes = new QPushButton("Afficher Matières sans Notes", this);

    layout->addWidget(btnCreer);
    layout->addWidget(btnAssigner);
    layout->addWidget(btnLierSalle);
    layout->addWidget(btnAfficherSansNotes);

    // Connexion des boutons aux slots
    connect(btnCreer, &QPushButton::clicked, this, &fenetrematiere::creerMatiere);
    connect(btnLierSalle, &QPushButton::clicked, this, &fenetrematiere::lierSalle);
    connect(btnAfficherSansNotes, &QPushButton::clicked, this, &fenetrematiere::afficherMatiereSansNotes);

    // Correction : connect au bon slot avec un paramètre
    connect(btnAssigner, &QPushButton::clicked, [=]() {
        assignerEnseignant(nullptr);  // Assigner avec un nullptr temporaire (ou logique personnalisée)
    });
}

// Création de la matière
void fenetrematiere::creerMatiere() {
    QMessageBox::information(this, "Créer Matière", "Création de la matière en cours...");
}

// Assigner un enseignant (corrigé avec paramètre)
void fenetrematiere::assignerEnseignant(fenetreenseignant* ens) {
    if (ens) {
        enseignants.push_back(ens);
        QMessageBox::information(this, "Assigner Enseignant", "Enseignant assigné à la matière.");
    } else {
        QMessageBox::warning(this, "Erreur", "Aucun enseignant sélectionné.");
    }
}

// Lier une salle à une matière
void fenetrematiere::lierSalle() {
    QMessageBox::information(this, "Lier Salle", "Liaison de la salle en cours...");
}

// Afficher les matières sans notes
void fenetrematiere::afficherMatiereSansNotes() {
    QMessageBox::information(this, "Afficher Matières sans Notes", "Affichage des matières sans notes...");
}
