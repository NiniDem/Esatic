#include "fenetredocumentation.h"
#include <QMessageBox>

fenetredocumentation::fenetredocumentation(QWidget *parent) : QDialog(parent) {
    QVBoxLayout *layout = new QVBoxLayout(this);
    btnTech = new QPushButton("Documentation Technique", this);
    btnUser = new QPushButton("Manuel Utilisateur", this);

    layout->addWidget(btnTech);
    layout->addWidget(btnUser);

    connect(btnTech, &QPushButton::clicked, this, &fenetredocumentation::ouvrirDocTechnique);
    connect(btnUser, &QPushButton::clicked, this, &fenetredocumentation::ouvrirDocUtilisateur);
}

void fenetredocumentation::ouvrirDocTechnique() {
    QMessageBox::information(this, "Documentation Technique",
                             "Nom du Projet :\n"
                             "Système de Gestion Académique\n\n"
                             "1. Introduction\n"
                             "Ce projet est une application de gestion académique développée en C++ avec Qt pour l'interface graphique et MySQL pour la gestion des bases de données.\n"
                             "Il permet de gérer les enseignants, étudiants, départements, matières, collèges et notes, avec une interface intuitive et des fonctionnalités complètes.\n\n"
                             "2. Technologies Utilisées\n"
                             "Langage : C++\n"
                             "Interface Graphique : Qt (Qt6 Widgets)\n"
                             "Base de Données : MySQL\n"
                             "IDE : Qt Creator\n"
                             "Système d'Exploitation : Windows / Linux\n\n"
                             "3. Architecture du Projet\n"
                             "Le projet est organisé en plusieurs classes, chaque classe représentant une fenêtre (QDialog) pour gérer une entité spécifique.\n\n"
                             "Structure des Fichiers :\n"
                             ".\n"
                             "├── main.cpp\n"
                             "├── mainwindow.h / mainwindow.cpp\n"
                             "├── fenetreetudiant.h / fenetreetudiant.cpp\n"
                             "├── fenetreenseignant.h / fenetreenseignant.cpp\n"
                             "├── fenetredepartement.h / fenetredepartement.cpp\n"
                             "├── fenetrematiere.h / fenetrematiere.cpp\n"
                             "├── fenetrecollege.h / fenetrecollege.cpp\n"
                             "└── personne.h / personne.cpp\n"
                             );
}

void fenetredocumentation::ouvrirDocUtilisateur() {
    QMessageBox::information(this, "Manuel Utilisateur",
                             "Manuel Utilisateur\n\n"
                             "1. Lancement de l'Application\n"
                             "- Double-cliquez sur l'exécutable du projet ou lancez-le depuis Qt Creator.\n\n"
                             "2. Navigation dans l'Application\n"
                             "- Cliquez sur les boutons de l'interface principale pour accéder aux différentes sections :\n"
                             "  - Gérer les étudiants\n"
                             "  - Gérer les enseignants\n"
                             "  - Gérer les départements\n"
                             "  - Gérer les matières\n"
                             "  - Gérer les collèges\n"
                             "  - Gérer les notes\n\n"
                             "3. Gestion des Étudiants\n"
                             "- Ajouter un étudiant : Gérer les étudiants > Ajouter Étudiant > Remplissez le formulaire > Valider.\n"
                             "- Modifier / Supprimer : Sélectionnez un étudiant, puis cliquez sur Modifier ou Supprimer.\n\n"
                             "4. Notes et Moyennes\n"
                             "- Cliquez sur Gérer les notes pour ajouter/modifier des notes et calculer des moyennes.\n"
                             );
}
