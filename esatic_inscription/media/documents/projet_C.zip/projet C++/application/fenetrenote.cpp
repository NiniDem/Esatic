#include "fenetrenote.h"
#include "fenetreetudiant.h"
#include "fenetreenseignant.h"
#include "fenetrematiere.h"
#include <QMessageBox>

// Constructeur
fenetrenote::fenetrenote(QWidget *parent) : QDialog(parent), matiere(""), valeur(0) {
    QVBoxLayout *layout = new QVBoxLayout(this);
    btnAjouter = new QPushButton("Ajouter Note", this);
    btnModifier = new QPushButton("Modifier Note", this);
    btnMoyenneMatiere = new QPushButton("Calculer Moyenne par Matière", this);
    btnMoyenneDepartement = new QPushButton("Calculer Moyenne par Département", this);
    btnDetecter = new QPushButton("Détecter Matières sans Notes", this);

    layout->addWidget(btnAjouter);
    layout->addWidget(btnModifier);
    layout->addWidget(btnMoyenneMatiere);
    layout->addWidget(btnMoyenneDepartement);
    layout->addWidget(btnDetecter);

    // Connexion des boutons aux slots
    connect(btnAjouter, &QPushButton::clicked, this, &fenetrenote::ajouterNote);
    connect(btnModifier, &QPushButton::clicked, this, &fenetrenote::modifierNote);
    connect(btnMoyenneMatiere, &QPushButton::clicked, this, &fenetrenote::calculerMoyenneParMatiere);
    connect(btnMoyenneDepartement, &QPushButton::clicked, this, &fenetrenote::calculerMoyenneParDepartement);
    connect(btnDetecter, &QPushButton::clicked, this, &fenetrenote::detecterMatieresSansNotes);
}

// Ajout de la note
void fenetrenote::ajouterNote() {
    QMessageBox::information(this, "Ajouter Note", "Ajout de note en cours...");
    matiere = "Mathématiques";  // Exemple temporaire
    valeur = 15.5;
}

// Modification de la note
void fenetrenote::modifierNote() {
    QMessageBox::information(this, "Modifier Note", "Modification de note en cours...");
}

// Calcul de la moyenne par matière
void fenetrenote::calculerMoyenneParMatiere() {
    QMessageBox::information(this, "Calculer Moyenne", "Calcul de la moyenne par matière en cours...");
}

// Calcul de la moyenne par département
void fenetrenote::calculerMoyenneParDepartement() {
    QMessageBox::information(this, "Calculer Moyenne", "Calcul de la moyenne par département en cours...");
}

// Détection des matières sans notes
void fenetrenote::detecterMatieresSansNotes() {
    QMessageBox::information(this, "Détecter Matières", "Détection des matières sans notes en cours...");
}

// Renvoie la valeur de la note
float fenetrenote::getValeur() const {
    return valeur;
}

// Renvoie la matière
std::string fenetrenote::getMatiere() const {
    return matiere;
}
