#include "connexion_mysql.h"
#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>
#include <QMessageBox>
#include <QInputDialog>

// Fonction de connexion à la base de données SQLite
static bool vraiconnexionBD() {
    QSqlDatabase conn = QSqlDatabase::addDatabase("QSQLITE");  // Utilisation de SQLite
    conn.setDatabaseName("base_de_donnees.db");  // Chemin vers votre fichier SQLite

    if (!conn.open()) {
        QMessageBox::critical(nullptr, "Erreur de connexion",
                              "Connexion à la base de données échouée : " + conn.lastError().text());
        return false;
    }
    QMessageBox::information(nullptr, "Connexion réussie",
                             "Connexion établie avec succès à la base de données.");
    return true;
}

// Ajouter un enseignant
static void ajouterEnseignant() {
    if (!vraiconnexionBD()) return;

    QSqlQuery query;
    QString nom = QInputDialog::getText(nullptr, "Ajouter Enseignant", "Nom :");
    QString prenom = QInputDialog::getText(nullptr, "Ajouter Enseignant", "Prénom :");
    QString tel = QInputDialog::getText(nullptr, "Ajouter Enseignant", "Téléphone :");
    QString mail = QInputDialog::getText(nullptr, "Ajouter Enseignant", "Mail :");
    QString date = QInputDialog::getText(nullptr, "Ajouter Enseignant", "Date de prise de fonction (AAAA-MM-JJ) :");
    int indice = QInputDialog::getInt(nullptr, "Ajouter Enseignant", "Indice :");
    QString matiere = QInputDialog::getText(nullptr, "Ajouter Enseignant", "Matière :");

    query.prepare("INSERT INTO enseignants (nom, prenom, tel, mail, datePriseFonction, indice, matiere) "
                  "VALUES (:nom, :prenom, :tel, :mail, :date, :indice, :matiere)");
    query.bindValue(":nom", nom);
    query.bindValue(":prenom", prenom);
    query.bindValue(":tel", tel);
    query.bindValue(":mail", mail);
    query.bindValue(":date", date);
    query.bindValue(":indice", indice);
    query.bindValue(":matiere", matiere);

    if (query.exec()) {
        QMessageBox::information(nullptr, "Succès", "Enseignant ajouté avec succès !");
    } else {
        QMessageBox::critical(nullptr, "Erreur", "Erreur lors de l'ajout : " + query.lastError().text());
    }
}

// Modifier un enseignant
static void modifierEnseignant() {
    if (!vraiconnexionBD()) return;

    QString nomEnseignant = QInputDialog::getText(nullptr, "Modifier Enseignant",
                                                  "Nom de l'enseignant à modifier :");
    if (nomEnseignant.isEmpty()) return;

    QString nouvelleMatiere = QInputDialog::getText(nullptr, "Modifier Enseignant",
                                                    "Nouvelle matière :");

    QSqlQuery query;
    query.prepare("UPDATE enseignants SET matiere = :matiere WHERE nom = :nom");
    query.bindValue(":matiere", nouvelleMatiere);
    query.bindValue(":nom", nomEnseignant);

    if (query.exec()) {
        QMessageBox::information(nullptr, "Succès", "Enseignant modifié avec succès !");
    } else {
        QMessageBox::critical(nullptr, "Erreur", "Erreur lors de la modification : " + query.lastError().text());
    }
}

// Changer Responsable
static void changerResponsable() {
    if (!vraiconnexionBD()) return;

    QString nomDepartement = QInputDialog::getText(nullptr, "Changer Responsable",
                                                   "Nom du département :");
    if (nomDepartement.isEmpty()) return;

    QString nomResponsable = QInputDialog::getText(nullptr, "Changer Responsable",
                                                   "Nom du nouvel enseignant responsable :");
    if (nomResponsable.isEmpty()) return;

    QSqlQuery query;
    query.prepare("UPDATE departements SET responsable = :responsable WHERE nom = :nom");
    query.bindValue(":responsable", nomResponsable);
    query.bindValue(":nom", nomDepartement);

    if (query.exec()) {
        QMessageBox::information(nullptr, "Succès", "Responsable modifié avec succès !");
    } else {
        QMessageBox::critical(nullptr, "Erreur", "Erreur lors du changement de responsable : " + query.lastError().text());
    }
}

// Ajouter un collège
void ajouterCollege(QString nom, QString adresse, QString site, QString directeur, QString tel) {
    if (!vraiconnexionBD()) return;

    QSqlQuery query;
    query.prepare("INSERT INTO college (nom, adresse, site_web, directeur, telephone) "
                  "VALUES (:nom, :adresse, :site, :directeur, :tel)");
    query.bindValue(":nom", nom);
    query.bindValue(":adresse", adresse);
    query.bindValue(":site", site);
    query.bindValue(":directeur", directeur);
    query.bindValue(":tel", tel);

    if (query.exec()) {
        QMessageBox::information(nullptr, "Succès", "Collège ajouté avec succès !");
    } else {
        QMessageBox::critical(nullptr, "Erreur", "Erreur lors de l'ajout : " + query.lastError().text());
    }
}

// Modifier un collège
void modifierCollege(QString nom, QString adresse, QString site, QString directeur, QString tel) {
    if (!vraiconnexionBD()) return;

    QSqlQuery query;
    query.prepare("UPDATE college SET adresse = :adresse, site_web = :site, directeur = :directeur, telephone = :tel "
                  "WHERE nom = :nom");
    query.bindValue(":adresse", adresse);
    query.bindValue(":site", site);
    query.bindValue(":directeur", directeur);
    query.bindValue(":tel", tel);
    query.bindValue(":nom", nom);

    query.exec();
}

// Supprimer un collège
void supprimerCollege(QString nom) {
    if (!vraiconnexionBD()) return;

    QSqlQuery query;
    query.prepare("DELETE FROM college WHERE nom = :nom");
    query.bindValue(":nom", nom);

    query.exec();
}

// Fonction pour créer les tables si elles n'existent pas déjà
void creerTables() {
    QSqlQuery query;

    // Table 'enseignants'
    query.exec("CREATE TABLE IF NOT EXISTS enseignants ("
               "id INTEGER PRIMARY KEY AUTOINCREMENT, "
               "nom TEXT, "
               "prenom TEXT, "
               "tel TEXT, "
               "mail TEXT, "
               "datePriseFonction TEXT, "
               "indice INTEGER, "
               "matiere TEXT);");

    // Table 'departements'
    query.exec("CREATE TABLE IF NOT EXISTS departements ("
               "id INTEGER PRIMARY KEY AUTOINCREMENT, "
               "nom TEXT, "
               "responsable TEXT);");

    // Table 'college'
    query.exec("CREATE TABLE IF NOT EXISTS college ("
               "id INTEGER PRIMARY KEY AUTOINCREMENT, "
               "nom TEXT, "
               "adresse TEXT, "
               "site_web TEXT, "
               "directeur TEXT, "
               "telephone TEXT);");
}
