// Fichier: departement.h
#ifndef DEPARTEMENT_H
#define DEPARTEMENT_H
#include "enseignant.h"
#include <vector>

class departement {
private:
    std::string nom;
    enseignant* responsable;
    std::vector<enseignant*> enseignants;

public:
    departement(std::string n);
    void ajouterEnseignant(enseignant* ens);
    void definirResponsable(enseignant* ens);
    void afficherInfos() const;
};

#endif
