#ifndef FENETREDEPARTEMENT_H
#define FENETREDEPARTEMENT_H

#include <QDialog>
#include <QVBoxLayout>
#include <QPushButton>
#include <vector>
#include <string>
#include "fenetreenseignant.h"

class fenetredepartement : public QDialog {
    Q_OBJECT
public:
    explicit fenetredepartement(QWidget *parent = nullptr, std::string n = "");  // Constructeur
    std::string getNom() const;   // Méthode pour obtenir le nom du département
    void setNom(const std::string& nouveauNom);  // Méthode pour définir le nom du département

private slots:
    void creerDepartement();
    void assignerEnseignant();
    void changerResponsable();

private:
    std::string nom;
    fenetreenseignant* responsable;
    std::vector<fenetreenseignant*> enseignants;

    QPushButton *btnCreer;
    QPushButton *btnAssigner;
    QPushButton *btnResponsable;
};

#endif
