// Fichier: enseignant.h
#ifndef ENSEIGNANT_H
#define ENSEIGNANT_H
#include "personne.h"
#include <iostream>
#include <string>

class enseignant : public personne {
private:
    std::string datePriseFonction;
    int indice;
    std::string matiere;

public:
    enseignant(std::string n, std::string p, std::string t, std::string m, std::string date, int i, std::string mat);
    void assignerMatiere(std::string mat);
    void afficherFiche() const override;
};

#endif
