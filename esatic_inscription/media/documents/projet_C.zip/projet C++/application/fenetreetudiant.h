#ifndef FENETREETUDIANT_H
#define FENETREETUDIANT_H
#include <QDialog>
#include <string>
#include <vector>
#include <utility>
#include <QPushButton>
#include <QVBoxLayout>
#include "personne.h"

class fenetreetudiant : public QDialog, public personne {
    Q_OBJECT
public:
    fenetreetudiant(std::string n, std::string p, std::string t, std::string m, int annee, QWidget *parent = nullptr);
    fenetreetudiant(QWidget *parent = nullptr);  // Ajout du constructeur par défaut

    // Implémentation des méthodes virtuelles
    void afficherFiche() const override;
    std::string getNom() const override;

private slots:
    void ajouterEtudiant();
    void modifierEtudiant();
    void supprimerEtudiant();
    void inscrireMatiere();
    void ajouterNote(const std::string& matiere, float note);
    void calculerMoyenne();
    void imprimerFiche();

private:
    QPushButton *btnAjouter;
    QPushButton *btnModifier;
    QPushButton *btnSupprimer;
    QPushButton *btnInscrire;
    QPushButton *btnNotes;
    QPushButton *btnMoyenne;
    QPushButton *btnFiche;
    int anneeEntree;
    std::vector<std::pair<std::string, float>> notes;
};

#endif
