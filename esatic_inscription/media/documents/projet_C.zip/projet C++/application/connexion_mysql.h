#ifndef CONNEXION_MYSQL_H
#define CONNEXION_MYSQL_H

#include <QSqlDatabase>
#include <QSqlQuery>
#include <QSqlError>
#include <QMessageBox>
#include <QInputDialog>
#include <QString>

// Fonction de connexion à la base de données
static bool vraiconnexionBD();

// Ajouter un enseignant
static void ajouterEnseignant();

// Modifier un enseignant
static void modifierEnseignant();

// Changer Responsable
static void changerResponsable();

// Ajouter un collège
void ajouterCollege(QString nom, QString adresse, QString site, QString directeur, QString tel);

// Modifier un collège
void modifierCollege(QString nom, QString adresse, QString site, QString directeur, QString tel);

// Supprimer un collège
void supprimerCollege(QString nom);

#endif // CONNEXION_MYSQL_H
