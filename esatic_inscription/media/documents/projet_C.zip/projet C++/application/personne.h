#ifndef PERSONNE_H
#define PERSONNE_H
#include <string>

class personne {
public:
    personne(std::string n, std::string p, std::string t, std::string m);  // Déclaration uniquement

    virtual void afficherFiche() const = 0;  // Méthode virtuelle pure
    virtual std::string getNom() const = 0;

    virtual ~personne() = default;  // Destructeur virtuel

protected:
    std::string nom;
    std::string prenom;
    std::string tel;
    std::string mail;
};

#endif
