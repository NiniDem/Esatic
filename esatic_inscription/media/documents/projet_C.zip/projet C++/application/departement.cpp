
// Fichier: departement.cpp
#include "departement.h"

departement::departement(std::string n) : nom(n), responsable(nullptr) {}

void departement::ajouterEnseignant(enseignant* ens) {
    enseignants.push_back(ens);
}

void departement::definirResponsable(enseignant* ens) {
    responsable = ens;
}

void departement::afficherInfos() const {
    std::cout << "Departement: " << nom << "\n";
    if (responsable) {
        std::cout << "Responsable: " << responsable->getnom() << " " << responsable->getprenom() << "\n";
    }
}
