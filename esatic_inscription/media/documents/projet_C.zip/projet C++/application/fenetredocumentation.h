#ifndef FENETREDOCUMENTATION_H
#define FENETREDOCUMENTATION_H
#include <QDialog>
#include <QPushButton>
#include <QVBoxLayout>

class fenetredocumentation : public QDialog {
    Q_OBJECT
public:
    fenetredocumentation(QWidget *parent = nullptr);

private slots:
    void ouvrirDocTechnique();
    void ouvrirDocUtilisateur();

private:
    QPushButton *btnTech;
    QPushButton *btnUser;
};

#endif
