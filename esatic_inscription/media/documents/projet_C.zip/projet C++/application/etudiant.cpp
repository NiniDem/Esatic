// Fichier: etudiant.cpp
#include "etudiant.h"

etudiant::etudiant(std::string n, std::string p, std::string t, std::string m, int annee)
    : personne(n, p, t, m), anneeEntree(annee) {}

void etudiant::ajouterNote(std::string matiere, float note) {
    notes.push_back({matiere, note});
}

float etudiant::calculerMoyenne() const {
    if (notes.empty()) return 0.0;
    float somme = 0;
    for (const auto& n : notes) {
        somme += n.second;
    }
    return somme / notes.size();
}

void etudiant::afficherFiche() const {
    std::cout << "Etudiant: " << nom << " " << prenom << "\n";
    std::cout << "Moyenne: " << calculerMoyenne() << "\n";
}
