// Fichier: etudiant.h
#ifndef ETUDIANT_H
#define ETUDIANT_H
#include "personne.h"
#include <vector>
#include <utility>
#include <iostream>

class etudiant : public personne {
private:
    int anneeEntree;
    std::vector<std::pair<std::string, float>> notes;

public:
    etudiant(std::string n, std::string p, std::string t, std::string m, int annee);
    void ajouterNote(std::string matiere, float note);
    float calculerMoyenne() const;
    void afficherFiche() const override;
};

#endif
