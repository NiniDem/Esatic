// Fichier: matiere.h
#ifndef MATIERE_H
#define MATIERE_H
#include "enseignant.h"
#include <vector>

class matiere {
private:
    std::string nom;
    std::string salle;
    int capacite;
    std::vector<enseignant*> enseignants;

public:
    matiere(std::string n, std::string s, int c);
    void ajouterEnseignant(enseignant* ens);
    void afficherInfos() const;
};

#endif
