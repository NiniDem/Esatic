// Fichier: fenetreenote.h
#ifndef FENETRENOTE_H
#define FENETRENOTE_H
#include <QDialog>
#include <QVBoxLayout>
#include <QPushButton>
#include <string>

class fenetrenote : public QDialog {
    Q_OBJECT
public:
    fenetrenote(QWidget *parent = nullptr);
    float getValeur() const;
    std::string getMatiere() const;

private slots:
    void ajouterNote();
    void modifierNote();
    void calculerMoyenneParMatiere();
    void calculerMoyenneParDepartement();
    void detecterMatieresSansNotes();

private:
    QPushButton *btnAjouter;
    QPushButton *btnModifier;
    QPushButton *btnMoyenneMatiere;
    QPushButton *btnMoyenneDepartement;
    QPushButton *btnDetecter;
    std::string matiere;
    float valeur;

};

#endif


