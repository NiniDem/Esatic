#include "mainwindow.h"
#include <QWidget>

MainWindow::MainWindow(QWidget *parent) : QMainWindow(parent) {
    QWidget *central = new QWidget(this);
    QVBoxLayout *layout = new QVBoxLayout(central);

    // Création des boutons
    btnEnseignants = new QPushButton("Gérer les enseignants", this);
    btnDepartements = new QPushButton("Gérer les départements", this);
    btnMatieres = new QPushButton("Gérer les matières", this);
    btnColleges = new QPushButton("Gérer les collèges", this);
    btnNotes = new QPushButton("Gérer les notes", this);
    btnEtudiant = new QPushButton("Gérer les étudiants", this);
    btnDocumentation = new QPushButton("DOCUMENTATION", this);  // Bouton documentation

    // Ajout au layout
    layout->addWidget(btnEnseignants);
    layout->addWidget(btnDepartements);
    layout->addWidget(btnMatieres);
    layout->addWidget(btnColleges);
    layout->addWidget(btnNotes);
    layout->addWidget(btnEtudiant);
    layout->addWidget(btnDocumentation);  // Ajout bouton documentation

    setCentralWidget(central);

    // Connexion des boutons aux slots
    connect(btnEnseignants, &QPushButton::clicked, this, &MainWindow::ouvrirGestionEnseignant);
    connect(btnDepartements, &QPushButton::clicked, this, &MainWindow::ouvrirGestionDepartement);
    connect(btnMatieres, &QPushButton::clicked, this, &MainWindow::ouvrirGestionMatiere);
    connect(btnColleges, &QPushButton::clicked, this, &MainWindow::ouvrirGestionCollege);
    connect(btnNotes, &QPushButton::clicked, this, &MainWindow::ouvrirGestionNote);
    connect(btnEtudiant, &QPushButton::clicked, this, &MainWindow::ouvrirGestionEtudiant);
    connect(btnDocumentation, &QPushButton::clicked, this, &MainWindow::ouvrirGestionDocumentation);  // Connexion correcte
}


void MainWindow::ouvrirGestionEtudiant() {
    fenetreetudiant *fenetre = new fenetreetudiant(this);
    fenetre->show();
}

void MainWindow::ouvrirGestionEnseignant() {
    fenetreenseignant *fenetre = new fenetreenseignant(this);
    fenetre->show();
}

void MainWindow::ouvrirGestionDepartement() {
    fenetredepartement *fenetre = new fenetredepartement(this);
    fenetre->show();
}

void MainWindow::ouvrirGestionMatiere() {
    fenetrematiere *fenetre = new fenetrematiere(this);
    fenetre->show();
}

void MainWindow::ouvrirGestionCollege() {
    fenetrecollege *fenetre = new fenetrecollege(this);
    fenetre->show();
}

void MainWindow::ouvrirGestionNote() {
    fenetrenote *fenetre = new fenetrenote(this);
    fenetre->show();
}

void MainWindow::ouvrirGestionDocumentation() {
    fenetredocumentation *fenetre = new fenetredocumentation(this);
    fenetre->show();
}
