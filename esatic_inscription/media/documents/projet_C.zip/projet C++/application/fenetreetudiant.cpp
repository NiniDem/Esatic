#include "fenetreetudiant.h"
#include <QMessageBox>

// Constructeur par défaut
fenetreetudiant::fenetreetudiant(QWidget *parent) :
    QDialog(parent), personne("", "", "", ""), anneeEntree(0) {

    QVBoxLayout *layout = new QVBoxLayout(this);
    btnAjouter = new QPushButton("Ajouter Étudiant", this);
    btnModifier = new QPushButton("Modifier Étudiant", this);
    btnSupprimer = new QPushButton("Supprimer Étudiant", this);
    btnInscrire = new QPushButton("Inscrire à une Matière", this);
    btnNotes = new QPushButton("Gérer Notes", this);
    btnMoyenne = new QPushButton("Calculer Moyenne", this);
    btnFiche = new QPushButton("Imprimer Fiche", this);

    layout->addWidget(btnAjouter);
    layout->addWidget(btnModifier);
    layout->addWidget(btnSupprimer);
    layout->addWidget(btnInscrire);
    layout->addWidget(btnNotes);
    layout->addWidget(btnMoyenne);
    layout->addWidget(btnFiche);

    connect(btnAjouter, &QPushButton::clicked, this, &fenetreetudiant::ajouterEtudiant);
    connect(btnModifier, &QPushButton::clicked, this, &fenetreetudiant::modifierEtudiant);
    connect(btnSupprimer, &QPushButton::clicked, this, &fenetreetudiant::supprimerEtudiant);
    connect(btnInscrire, &QPushButton::clicked, this, &fenetreetudiant::inscrireMatiere);
    connect(btnNotes, &QPushButton::clicked, this, &fenetreetudiant::calculerMoyenne);
    connect(btnFiche, &QPushButton::clicked, this, &fenetreetudiant::imprimerFiche);
}

// Constructeur avec paramètres
fenetreetudiant::fenetreetudiant(std::string n, std::string p, std::string t, std::string m, int annee, QWidget *parent) :
    QDialog(parent), personne(n, p, t, m), anneeEntree(annee) {}

void fenetreetudiant::afficherFiche() const {
    QMessageBox::information(nullptr, "Fiche Étudiant",
                             QString::fromStdString("Nom: " + nom + "\nPrénom: " + prenom + "\nTéléphone: " + tel + "\nMail: " + mail));
}

std::string fenetreetudiant::getNom() const {
    return nom;
}

// Méthodes slots
void fenetreetudiant::ajouterEtudiant() {
    QMessageBox::information(this, "Ajouter Étudiant", "Ajout d'un étudiant en cours...");
}

void fenetreetudiant::modifierEtudiant() {
    QMessageBox::information(this, "Modifier Étudiant", "Modification d'un étudiant...");
}

void fenetreetudiant::supprimerEtudiant() {
    QMessageBox::information(this, "Supprimer Étudiant", "Suppression d'un étudiant...");
}

void fenetreetudiant::inscrireMatiere() {
    QMessageBox::information(this, "Inscrire Matière", "Inscription à une matière...");
}

void fenetreetudiant::ajouterNote(const std::string& matiere, float note) {
    notes.push_back(std::make_pair(matiere, note));
    QMessageBox::information(this, "Ajouter Note", "Note ajoutée pour " + QString::fromStdString(matiere));
}

void fenetreetudiant::calculerMoyenne() {
    if (notes.empty()) {
        QMessageBox::information(this, "Calcul Moyenne", "Aucune note disponible.");
        return;
    }

    float somme = 0;
    for (const auto& n : notes) {
        somme += n.second;
    }
    float moyenne = somme / notes.size();
    QMessageBox::information(this, "Moyenne", "Moyenne : " + QString::number(moyenne));
}

void fenetreetudiant::imprimerFiche() {
    QMessageBox::information(this, "Imprimer Fiche", "Impression de la fiche étudiant...");
}
