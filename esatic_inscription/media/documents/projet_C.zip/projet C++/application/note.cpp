// Fichier: note.cpp
#include "note.h"

note::note(std::string m, float v) : matiere(m), valeur(v) {}

float note::getValeur() const {
    return valeur;
}

std::string note::getMatiere() const {
    return matiere;
}

