#include "fenetreenseignant.h"
#include "connexion_mysql.h"
#include <QMessageBox>
#include <QInputDialog>
#include <QSqlQuery>
#include <QSqlError>

// Constructeur par défaut
fenetreenseignant::fenetreenseignant(QWidget *parent) :
    QDialog(parent), personne("", "", "", ""), datePriseFonction(""), indice(0), matiere("") {

    QVBoxLayout *layout = new QVBoxLayout(this);
    btnAjouter = new QPushButton("Ajouter Enseignant", this);
    btnModifier = new QPushButton("Modifier Enseignant", this);
    btnSupprimer = new QPushButton("Supprimer Enseignant", this);
    btnImprimerFiche = new QPushButton("Imprimer Fiche", this);

    layout->addWidget(btnAjouter);
    layout->addWidget(btnModifier);
    layout->addWidget(btnSupprimer);
    layout->addWidget(btnImprimerFiche);

    connect(btnAjouter, &QPushButton::clicked, this, &fenetreenseignant::ajouter);
    connect(btnModifier, &QPushButton::clicked, this, &fenetreenseignant::modifier);
    connect(btnSupprimer, &QPushButton::clicked, this, &fenetreenseignant::supprimer);
    connect(btnImprimerFiche, &QPushButton::clicked, this, &fenetreenseignant::imprimerFiche);
}

// Constructeur avec paramètres
fenetreenseignant::fenetreenseignant(std::string n, std::string p, std::string t, std::string m,
                                     std::string date, int i, std::string mat, QWidget *parent) :
    QDialog(parent), personne(n, p, t, m), datePriseFonction(date), indice(i), matiere(mat) {}

// Ajouter un enseignant à la base de données
void fenetreenseignant::ajouter() {
    if (!vraiconnexionBD()) return;

    QSqlQuery query;
    query.prepare("INSERT INTO enseignants (nom, prenom, tel, mail, datePriseFonction, indice, matiere) "
                  "VALUES (:nom, :prenom, :tel, :mail, :date, :indice, :matiere)");
    query.bindValue(":nom", QString::fromStdString(nom));
    query.bindValue(":prenom", QString::fromStdString(prenom));
    query.bindValue(":tel", QString::fromStdString(tel));
    query.bindValue(":mail", QString::fromStdString(mail));
    query.bindValue(":date", QString::fromStdString(datePriseFonction));
    query.bindValue(":indice", indice);
    query.bindValue(":matiere", QString::fromStdString(matiere));

    if (query.exec()) {
        QMessageBox::information(this, "Succès", "Enseignant ajouté avec succès !");
    } else {
        QMessageBox::critical(this, "Erreur", "Erreur lors de l'ajout : " + query.lastError().text());
    }
}

// Modifier les informations d'un enseignant
void fenetreenseignant::modifier() {
    if (!vraiconnexionBD()) return;

    QString nomEnseignant = QInputDialog::getText(this, "Modifier Enseignant",
                                                  "Nom de l'enseignant à modifier :");
    if (nomEnseignant.isEmpty()) return;

    QString nouvelleMatiere = QInputDialog::getText(this, "Modifier Enseignant",
                                                    "Nouvelle matière :");

    QSqlQuery query;
    query.prepare("UPDATE enseignants SET matiere = :matiere WHERE nom = :nom");
    query.bindValue(":matiere", nouvelleMatiere);
    query.bindValue(":nom", nomEnseignant);

    if (query.exec()) {
        QMessageBox::information(this, "Succès", "Enseignant modifié avec succès !");
    } else {
        QMessageBox::critical(this, "Erreur", "Erreur lors de la modification : " + query.lastError().text());
    }
}

// Supprimer un enseignant
void fenetreenseignant::supprimer() {
    if (!vraiconnexionBD()) return;

    QString nomEnseignant = QInputDialog::getText(this, "Supprimer Enseignant",
                                                  "Nom de l'enseignant à supprimer :");
    if (nomEnseignant.isEmpty()) return;

    QSqlQuery query;
    query.prepare("DELETE FROM enseignants WHERE nom = :nom");
    query.bindValue(":nom", nomEnseignant);

    if (query.exec()) {
        QMessageBox::information(this, "Succès", "Enseignant supprimé avec succès !");
    } else {
        QMessageBox::critical(this, "Erreur", "Erreur lors de la suppression : " + query.lastError().text());
    }
}


// Imprimer la fiche signalétique
void fenetreenseignant::imprimerFiche() {
    if (!vraiconnexionBD()) return;

    QSqlQuery query;
    query.prepare("SELECT * FROM enseignants WHERE nom = :nom");
    query.bindValue(":nom", QString::fromStdString(nom));

    if (query.exec() && query.next()) {
        QString info = "Nom: " + query.value("nom").toString() +
                       "\nPrénom: " + query.value("prenom").toString() +
                       "\nTéléphone: " + query.value("tel").toString() +
                       "\nMail: " + query.value("mail").toString();
        QMessageBox::information(this, "Fiche Enseignant", info);
    } else {
        QMessageBox::critical(this, "Erreur", "Enseignant introuvable.");
    }
}


// Implémentation de afficherFiche (hérité de personne)
void fenetreenseignant::afficherFiche() const {
    QString fiche = "Nom: " + QString::fromStdString(nom) +
                    "\nPrénom: " + QString::fromStdString(prenom) +
                    "\nTéléphone: " + QString::fromStdString(tel) +
                    "\nMail: " + QString::fromStdString(mail) +
                    "\nMatière: " + QString::fromStdString(matiere) +
                    "\nDate de prise de fonction: " + QString::fromStdString(datePriseFonction);

    QMessageBox::information(nullptr, "Fiche Enseignant", fiche);
}

// Implémentation de getNom (hérité de personne)
std::string fenetreenseignant::getNom() const {
    return nom;
}
